var Cliente = Backbone.Model.extend({
	defaults: {
		id: "",
		nombre: "",
		apellido: "",
		edad: 0.0,
		telefono: "",
		email: ""
	}
});